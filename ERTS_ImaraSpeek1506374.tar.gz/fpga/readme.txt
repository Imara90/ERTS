Please put your c code for FPGA board here.
Use main.c as your main c code.

You can make and upload your code using:
make uploadrun




Cheers, 
Lab Assistants.
